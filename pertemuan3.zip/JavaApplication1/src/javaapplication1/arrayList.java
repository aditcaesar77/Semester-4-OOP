/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.ArrayList;
/**
 *
 * @author INSTIKI
 */
public class arrayList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList dataku = new ArrayList();
        
        dataku.add("saya");
        dataku.add(50);
        dataku.add(13.4);
        dataku.add("buah");
        
        System.out.println(dataku);
    }   
}
