/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author INSTIKI
 */
public class arrayTugas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner masukan = new Scanner(System.in);
        String buah[] = new String[5];
        for(int i = 0; i<buah.length; i++){
            System.out.println("Masukkan Buah ke "+(i)+":");
            buah[i]=masukan.nextLine();  
        }for (int j = 0; j<buah.length; j++){
                System.out.println(j + ". "+buah[j]);
            }
    }
    
}
