/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author INSTIKI
 */
public class array {
    public static void main(String[]args){
        String nama[][] = {{"aditya", "caesar", "surya"},{"ahmad", "arya","jony"}};
        
//        System.out.println(nama[0][0]);
//        System.out.println(nama[0][1]);
//        System.out.println(nama[0][2]);
//        System.out.println(nama[1][0]);
//        System.out.println(nama[1][1]);
//        System.out.println(nama[1][2]);
        for(int a=0; a<nama.length; a++){
            for(int b=0; b<nama[0].length; b++){
                System.out.println(nama[a][b]);
            }
        }
    }
}
