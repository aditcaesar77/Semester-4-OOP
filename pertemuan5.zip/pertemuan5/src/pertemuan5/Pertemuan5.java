/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan5;

/**
 *
 * @author PC-A-30
 */

class segitiga{
    int alas,tinggi,hasil;
    
    public int luassegitiga(){
        hasil = alas * tinggi/2;
        System.out.println("Luas segitiga adalah :"+hasil);
        return hasil;
    }
}

public class Pertemuan5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        segitiga tiga = new segitiga();
        
        tiga.alas = 8;
        tiga.tinggi = 10;
        tiga.luassegitiga();
    }
    
}
