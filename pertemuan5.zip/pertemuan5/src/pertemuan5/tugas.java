/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan5;
import java.util.Scanner;
/**
 *
 * @author PC-A-30
 */
class tampil {
   Scanner masukan = new Scanner (System.in);
   String nama;
   int nim;
   String jurusan;
   public void masukkan(){
       System.out.print("Silakan Masukkan Nama :");
       nama=masukan.nextLine();
       System.out.print("Silakan Masukkan Nim :");
       nim=masukan.nextInt();
       masukan.nextLine();
       System.out.print("Silakan Masukkan Jurusan :");
       jurusan=masukan.nextLine();
       
       System.out.println("nama anda :"+nama);
       System.out.println("nim anda :"+nim);
       System.out.println("jurusan anda :"+jurusan);
   }
   

}
public class tugas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        tampil show = new tampil();
        show.masukkan();
    }
    
}
